import React from 'react'
import '../../styles/cart.scss'
import { FaTrashAlt } from 'react-icons/fa'
import CartTitle from './CartTitle'
import CartItemNav from './CartItemNav'

const index = () => {
  return (
    <>
      <div className="container ">
        <CartTitle />
      </div>
      <CartItemNav />
      <div className="cartMain">
        <div className="cartItemTitle">
          <h4>商品名稱</h4>
          <h4>單價</h4>
          <h4>數量</h4>
        </div>
        <div className="cartItem ">
          <h3>1.</h3>
          <img src="http://fakeimg.pl/440x320/282828/EAE0D0/" alt="" />
          <div className="cartItemDetil">
            <p>Amenity Dome寢室帳</p>
            <p>$14.900</p>
            <div className="cartItemDetilBtn">
              <button className="btn btn-primary">+</button>
              <p>3</p>
              <button className="btn btn-primary">-</button>
            </div>
            <button className="btn btn-primary">
              <FaTrashAlt />
            </button>
          </div>
        </div>
        <div className="cartItem ">
          <h3>2.</h3>
          <img src="http://fakeimg.pl/440x320/282828/EAE0D0/" alt="" />
          <div className="cartItemDetil">
            <p>Amenity Dome寢室帳</p>
            <p>$14.900</p>
            <div className="cartItemDetilBtn">
              <button className="btn btn-primary">+</button>
              <p>3</p>
              <button className="btn btn-primary">-</button>
            </div>
            <button className="btn btn-primary">
              <FaTrashAlt />
            </button>
          </div>
        </div>
      </div>
      <div className="cartPiceDetil">
        <div className="cartPiceDetilItem1">
          <p>品項:</p>
          <p>小計:</p>
          <p>
            選擇折價券: <input type="text" value="週年慶折50" />
          </p>
          <p>
            選擇運送方式: <input type="text" value="宅配 100/件" />
          </p>
        </div>
        <div className="cartPiceDetilItem2">
          <p>共2項</p>
          <p>NT $ 1130</p>
          <p>-NT $ 1130</p>
          <p>NT $ 300</p>
        </div>
      </div>
      <div className="cartPiceDetil">
        <h4>總計金額:&emsp;</h4>
        <h3>NT $ 11000</h3>
      </div>
      <div className="cartPiceBtn">
        <button>繼續選購</button>
        <button>下一步</button>
      </div>
    </>
  )
}

export default index
