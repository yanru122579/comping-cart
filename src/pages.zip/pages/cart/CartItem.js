import React from 'react'

const CartItem = () => {
  return <></>
}

export default CartItem
